(function($, window, document, undefined) {



	$(function() {
	});



})(jQuery, this, this.document);